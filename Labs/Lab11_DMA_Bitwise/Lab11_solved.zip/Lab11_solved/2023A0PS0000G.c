#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char passenger_name[30];
    unsigned int airfare;//base price of ticket
    unsigned int novelty_fee;//extra fee for flying with airline the first time
    unsigned int freq_flyer_points;//points for loyalty to the airline
}plane_ticket;

/**
 * Creates a new plane_ticket using the arguments passed.
 * 
 * You are NOT allowed to use * (the multiplication operator), /, % or math.h functions
 * 
 * The new plane_ticket should have the following attributes:
 * - passenger_name is customer_name
 * - airfare is base_price
 * - novelty_fee should be ⌊base_price/8⌋
 * - freq_flyer_points should be ⌊prev_flights/2⌋
 * @returns a pointer to the new plane_ticket
*/
plane_ticket* createTicket(char customer_name[], unsigned int base_price, unsigned int prev_flights)
{
    plane_ticket* newTicket = (plane_ticket*)malloc(sizeof(plane_ticket));
    strcpy(newTicket->passenger_name, customer_name);
    newTicket->airfare=base_price;
    newTicket->novelty_fee=base_price>>3;
    newTicket->freq_flyer_points=prev_flights>>1;
    return newTicket;
}

/**
 * Halves the novelty_fee for the given plane_ticket once for every frequent flyer point (freq_flyer_points).
 * @returns the difference between the actual initial novelty fee and the minimum initial novelty fee that would have given the same division result
 * 
 * You MAY USE + (the addition operator) and * (the multiplication operator)
 * You are NOT allowed to use - (the subtraction operator)!
 * You are NOT allowed to use /, %, or math.h functions
 * 
 * For example,
 * If the original p->novelty_fee is 61 and p->freq_flyer_points is 3,
 * You need to divide 61 by 2, 3 times, like so:
 * 61...30...15...7
 * 
 * So you should update p->novelty_fee to 7
 * 
 * The minimum original novelty fee that would have also given 7 is 56
 * 56...28...14...7
 * 
 * Hence, you should return 61 - 56, which is 5
 * BIG: HINT: see the image in README.md
*/
unsigned int claimBenefit(plane_ticket* p)
{
    unsigned int answer=0;
    for(unsigned int i=0; i < (p->freq_flyer_points); i++)
    {
        answer += ((p->novelty_fee) & 1) * (1<<i); // remainder * 2^i
        p->novelty_fee=(p->novelty_fee)>>1; //divide novelty_fee by 2
    }
    return answer;
}

/* --- DO NOT MODIFY BEYOND THIS POINT --- */
int main()
{
    char cn[30];
    unsigned int bp, pf;
    printf("TICKET BILLING PORTAL\n");
    printf("Customer name, no spaces\n:");
    scanf("%s", cn);
    printf("Ticket base price\n:");
    scanf("%u", &bp);
    printf("Number of previous flights\n:");
    scanf("%u", &pf);
    plane_ticket* goi_bom = createTicket(cn, bp, pf);
    int opt=-1;
    printf("OPTIONS\n1 View customer details\n2 Claim frequent flyer benefits\nEnter option\n:");
    scanf("%d", &opt);
    if(opt==1 || opt==2)
    {
        printf("\nName: %s\nAirfare: %u\nFrequent flyer points: %u\n\n", goi_bom->passenger_name, goi_bom->airfare, goi_bom->freq_flyer_points);
        if(opt==2)
            printf("BEFORE DISCOUNT\n");
        printf("Initial novelty fee: %u\nInitial bill amount: %u (airfare + novelty fee)\n\n", goi_bom->novelty_fee, goi_bom->airfare + goi_bom->novelty_fee);
    }
    if(opt==2)
    {
        unsigned int d = claimBenefit(goi_bom);
        printf("AFTER DISCOUNT\n");
        printf("Final novelty fee: %u\nDiscounted bill amount: %u (airfare + final novelty fee)\n\n", goi_bom->novelty_fee, goi_bom->airfare + goi_bom->novelty_fee);
        printf("Difference in actual and minimum novelty fees to get final as %u is: %d\n", (goi_bom->novelty_fee), d);
    }
    free(goi_bom);
    return 0;
}