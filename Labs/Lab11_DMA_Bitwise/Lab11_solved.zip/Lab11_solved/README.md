# Lab 11
Welcome to Lab 11. In this lab, you will learn how to use bitwise operators, and practice working with dynamic memory allocation.

## Instructions
If you haven't already, use the shortcut Ctrl + Shift + V to render the README.md file.

### Rename `Lab11.c` with your BITS ID.
Rename the given `Lab11.c` file to `YourBITSID.c`, where 'YourBITSID' is your 13-character BITS ID number. For example, if your ID number is 2023AXPS1234G, rename the file to `2023AXPS1234G.c`.

To rename a file, right-click it in the explorer, select 'Rename', type in the new name and click enter.

### Compilation instructions
To compile your programme at any point during the lab, open a new terminal (Terminal > New Terminal) amd type in:

```sh
gcc YourBITSID.c -o lab11
```

To run the compiled program, type in:

```sh
./lab11
```

### Task 1: complete the `createTicket` function
_Without_ using the multiplication * or division / operators, or library functions from `math.h`, complete the body of the `createTicket` function so that it does the following:
* Creates a pointer to a new `plane_ticket`, and populates its fields as follows:
    * `passenger_name` takes the value of the function argument `customer_name`
    * `airfare` takes the value the function argument `base_price`
    * `novelty_fee` takes the **floor** of the result of dividing the function argument `base_price` by 8
    * `freq_flyer_points` takes the **floor** of the result of dividing the function argument `prev_flights` by 2
* **Return** the pointer to the `plane_ticket` you have just created ;)

### Task 2: complete the `claimBenefit` function
Without using the **subtraction**, modulo or division operators (- % /), or library functions from `math.h`, complete the body of the `claimBenefit` function so that it does both of the following:

#### 2.1 Update `p->novelty_fee`
* For every frequent flyer mile `p->freq_flyer_points`, the value of `p->novelty_fee` should be halved.
    * For example, if `p->novelty_fee` is initially 61 and `p->freq_flyer_points` is 3, the final value of `p->novelty fee` is (((61/2)/2)/2) or 7

#### 2.2 Return different between actual and minimum initial `novelty_fee` that give same final answer
* Observe, for example, that if `freq_flyer_points` is 3, you can start with a `novelty_fee` value from 56 all the way to 63, and you would get the same final `novelty_fee` (here, 7) that you would if you had started with 61.
    * 55...27...13...6
    * 56...28...14...7
    * 57...28...14...7
    * ...
    * 62...31...15...7
    * 63...31...15...7
    * 64...32...16...8
* Your task is to return the **difference** between the original novelty fee you computed in `createTicket` (say, 61) and the minimum novelty fee (here, 56) that would have given the same final answer after the divisions in task 2.1.
* **HINT:** Here's how to calculate this:
![Image](claimBenefit_hint.png "Hint")

## Submit
We have provided some test cases with the code.
You can test your program against these by running the following command in the terminal:

```python
python3 autograder.py YourBITSID.c Lab11-tests.json
```

You should test your code for other input combinations as well.

### Prepare Submission
1. In the terminal, enter the following to make the `prepare_submission` executable:

   ```sh
   chmod u+x prepare_submission
   ```

3. Run `prepare_submission` to create `YourBITSID.tar.gz`:

   ```sh
   ./prepare_submission
   ```

4. Upload `YourBITSID.tar.gz` to the Lab 11 section at <https://quanta.bits-goa.ac.in/>.